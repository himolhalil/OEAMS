# OEAMS
## How To Run The Prjoect
1. inside the local folder of your server (e.g `www/` or `htdocs`)
```bash
git clone https://github.com/MuhammadFarouk12/OEAMS
```
2. create the database structured in the [database_scripts.sql](https://github.com/MuhammadFarouk12/OEAMS/blob/main/database_scripts.sql) file
3. edit your credentials in the [utilites.php](https://github.com/MuhammadFarouk12/OEAMS/blob/main/utilities/utilities.php) file
4. hit the link http://localhost/OEAMS/students/students.php in your browser
5. ENJOY 🎉
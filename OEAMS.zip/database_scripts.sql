-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: OEAMS
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `CLASS`
--

DROP TABLE IF EXISTS `CLASS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLASS` (
  `CLASS_ID` int(11) NOT NULL AUTO_INCREMENT,
  `COURSE_ID` int(11) DEFAULT NULL,
  `TERM_ID` int(11) DEFAULT NULL,
  `TEACHER_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`CLASS_ID`),
  KEY `FK_COURSE_CLASS` (`COURSE_ID`),
  KEY `FK_TERM_CLASS` (`TERM_ID`),
  KEY `FK_TEACHER_CLASS` (`TEACHER_ID`),
  CONSTRAINT `FK_COURSE_CLASS` FOREIGN KEY (`COURSE_ID`) REFERENCES `COURSE` (`COURSE_ID`),
  CONSTRAINT `FK_TEACHER_CLASS` FOREIGN KEY (`TEACHER_ID`) REFERENCES `TEACHER` (`TEACHER_ID`),
  CONSTRAINT `FK_TERM_CLASS` FOREIGN KEY (`TERM_ID`) REFERENCES `TERM` (`TERM_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLASS`
--

LOCK TABLES `CLASS` WRITE;
/*!40000 ALTER TABLE `CLASS` DISABLE KEYS */;
INSERT INTO `CLASS` VALUES (1,1,1,1),(2,2,1,2),(3,3,2,1);
/*!40000 ALTER TABLE `CLASS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COURSE`
--

DROP TABLE IF EXISTS `COURSE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COURSE` (
  `COURSE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `COURSE_NAME` varchar(255) DEFAULT NULL,
  `COURSE_BOOK` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`COURSE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COURSE`
--

LOCK TABLES `COURSE` WRITE;
/*!40000 ALTER TABLE `COURSE` DISABLE KEYS */;
INSERT INTO `COURSE` VALUES (1,'Introduction to Programming','Think Python 2e'),(2,'Web Development Fundamentals','HTML & CSS by Jon Duckett'),(3,'Database Systems','Database System Concepts');
/*!40000 ALTER TABLE `COURSE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTRATION`
--

DROP TABLE IF EXISTS `REGISTRATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REGISTRATION` (
  `REGISTRATION_ID` int(11) NOT NULL AUTO_INCREMENT,
  `STUDENT_ID` int(11) DEFAULT NULL,
  `CLASS_ID` int(11) DEFAULT NULL,
  `PRICE` int(11) DEFAULT NULL,
  `PAID` int(11) DEFAULT NULL,
  `PARTICIPATION_MARK` int(11) DEFAULT NULL,
  `ATTENDANCE_MARK` int(11) DEFAULT NULL,
  `MID_EXAM_MARK` int(11) DEFAULT NULL,
  `HOMEWORKS_MARK` int(11) DEFAULT NULL,
  `ACTIVITES_MARK` int(11) DEFAULT NULL,
  `FINAL_EXAM_MARK` int(11) DEFAULT NULL,
  `TEACHER_COMMENT` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`REGISTRATION_ID`),
  KEY `FK_STUDENT_REGISTRATION` (`STUDENT_ID`),
  KEY `FK_CLASS_REGISTRATION` (`CLASS_ID`),
  CONSTRAINT `FK_CLASS_REGISTRATION` FOREIGN KEY (`CLASS_ID`) REFERENCES `CLASS` (`CLASS_ID`),
  CONSTRAINT `FK_STUDENT_REGISTRATION` FOREIGN KEY (`STUDENT_ID`) REFERENCES `STUDENT` (`STUDENT_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTRATION`
--

LOCK TABLES `REGISTRATION` WRITE;
/*!40000 ALTER TABLE `REGISTRATION` DISABLE KEYS */;
INSERT INTO `REGISTRATION` VALUES (1,1,1,1500,1500,18,19,42,28,15,78,'Excellent progress.'),(2,2,1,1500,1000,15,16,35,22,12,65,'Needs more practice.'),(3,1,2,1200,1200,20,20,48,30,18,85,'Outstanding work.'),(4,3,3,1800,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `REGISTRATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STUDENT`
--

DROP TABLE IF EXISTS `STUDENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STUDENT` (
  `STUDENT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `FIRST_NAME` varchar(255) DEFAULT NULL,
  `MIDDLE_NAMES` varchar(255) DEFAULT NULL,
  `LAST_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_DATE` timestamp NULL DEFAULT NULL,
  `PHONE_NUMBER` varchar(255) DEFAULT NULL,
  `password` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`STUDENT_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STUDENT`
--

LOCK TABLES `STUDENT` WRITE;
/*!40000 ALTER TABLE `STUDENT` DISABLE KEYS */;
INSERT INTO `STUDENT` VALUES (1,'Muhmmad',NULL,'Farouk','2026-01-10 11:30:00','+966531112233','hashed_pass_f'),(2,'Fatima','Ali','Hassan','2026-01-12 06:15:00','+966542223344','hashed_pass_fat'),(3,'Yousef',NULL,'Nasser','2026-01-14 13:45:00','+966563334455','hashed_pass_y');
/*!40000 ALTER TABLE `STUDENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TEACHER`
--

DROP TABLE IF EXISTS `TEACHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TEACHER` (
  `TEACHER_ID` int(11) NOT NULL AUTO_INCREMENT,
  `FIRST_NAME` varchar(255) DEFAULT NULL,
  `MIDDLE_NAMES` varchar(255) DEFAULT NULL,
  `LAST_NAME` varchar(255) DEFAULT NULL,
  `PHONE_NUMBER` varchar(255) DEFAULT NULL,
  `password` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`TEACHER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TEACHER`
--

LOCK TABLES `TEACHER` WRITE;
/*!40000 ALTER TABLE `TEACHER` DISABLE KEYS */;
INSERT INTO `TEACHER` VALUES (1,'Ahmed',NULL,'Khalid','+966501234567','hashed_pass_1'),(2,'Layla','Mohammed','Al-Rashid','+966559876543','hashed_pass_2');
/*!40000 ALTER TABLE `TEACHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TERM`
--

DROP TABLE IF EXISTS `TERM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TERM` (
  `TERM_ID` int(11) NOT NULL AUTO_INCREMENT,
  `TERM_START` timestamp NULL DEFAULT NULL,
  `TERM_END` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`TERM_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TERM`
--

LOCK TABLES `TERM` WRITE;
/*!40000 ALTER TABLE `TERM` DISABLE KEYS */;
INSERT INTO `TERM` VALUES (1,'2026-01-14 21:00:00','2026-05-30 20:59:59'),(2,'2026-08-19 21:00:00','2026-12-15 20:59:59');
/*!40000 ALTER TABLE `TERM` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-19 21:19:23

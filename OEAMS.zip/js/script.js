function addClassTo(className, element){ 
	element.classList.add(className)	
}

function removeClassFrom(className, element){ 
	element.classList.remove(className)	
}